package com.sitech.dao;

import com.sitech.bo.GuestInfoBO;

public interface IguestDAO {
	
	public int insert(GuestInfoBO bo) throws Exception;

}
