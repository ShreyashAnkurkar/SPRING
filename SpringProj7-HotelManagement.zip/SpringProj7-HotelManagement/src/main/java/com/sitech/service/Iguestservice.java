package com.sitech.service;

import com.sitech.dto.guestInfoDTO;

public interface Iguestservice {
	
	public String registerGuest(guestInfoDTO dto) throws Exception;
	

}
